# Design System Document: Essentialist Editorial

## 1. Overview & Creative North Star
**Creative North Star: The Curated Archive**
This design system rejects the "data-heavy dashboard" aesthetic common in career platforms. Instead, it adopts the logic of a high-end architectural portfolio or a premium editorial magazine. The goal is to treat a user’s career not as a list of entries, but as a curated narrative of achievements.

We break the "template" look by utilizing **intentional asymmetry**—large, elegant Display type offset by generous white space—and **tonal depth**. By removing standard UI crutches like heavy borders and shadows, we force the layout to rely on proportion, micro-typography, and sophisticated layering to guide the user's eye.

---

## 2. Colors & Materiality
The palette is rooted in ultra-refined neutrals that allow content to breathe, punctuated by a single, high-intent 'Signature Indigo.'

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or containment. 
Structure must be defined exclusively through:
*   **Tonal Transitions:** Moving from `surface` (#f7f9fb) to `surface-container-low` (#f0f4f7) to define different content zones.
*   **Negative Space:** Using the Spacing Scale to create "implied boundaries."

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of premium paper. Use the surface-container tiers to create organic depth:
*   **Base:** `surface` for the primary background.
*   **Secondary Zones:** `surface-container-low` for sidebars or secondary content.
*   **Interactive Cards:** `surface-container-lowest` (#ffffff) to provide a subtle "lift" against the grey-toned backgrounds.

### Signature Textures & Glass
*   **The Glass Rule:** For floating navigation or overlays, use `surface-container-lowest` at 80% opacity with a `backdrop-filter: blur(12px)`. This integrates the element into the layout rather than making it feel like a disconnected pop-up.
*   **The Gradient Polish:** For primary high-intent actions, use a subtle linear gradient from `primary` (#4e5a9a) to `primary-dim` (#424e8d) at a 135-degree angle. This adds a "soul" to the Indigo that flat hex codes cannot achieve.

---

## 3. Typography: The Editorial Voice
We use **Manrope** across all scales, relying on extreme contrast between 'Display' and 'Label' styles to create a premium feel.

*   **Display & Headline:** Use `display-lg` and `headline-md` for primary section headers. These should be set with tight leading (1.1) to feel like architectural blocks.
*   **The Micro-Typography Rule:** Metadata (dates, tags, categories) must use `label-sm`. 
    *   *Styling:* Uppercase, `font-weight: 600`, and a `letter-spacing` of 0.08rem to 0.1rem. This transforms standard text into a decorative, premium element.
*   **Body Copy:** Use `body-lg` for primary reading. Ensure line-length is capped at 65 characters to maintain the "Editorial" readability standard.

---

## 4. Elevation & Depth
Depth in this system is a result of light and layering, never heavy shadows.

*   **The Layering Principle:** To highlight a specific card or module, do not add a border. Instead, place a `surface-container-lowest` card on top of a `surface-container-high` (#e1e9ee) background. The shift in value provides all the necessary affordance.
*   **Ambient Shadows:** If a floating state is required (e.g., a dropdown), use an extra-diffused shadow: `box-shadow: 0 12px 40px rgba(42, 52, 57, 0.06)`. Note the color: we use a tint of `on-surface` (#2a3439) rather than pure black to keep the shadow feeling natural and "airy."
*   **The Ghost Border Fallback:** For accessibility in input fields, use the `outline-variant` token at 20% opacity. It should be barely perceptible, serving as a hint rather than a wall.

---

## 5. Components

### Buttons
*   **Primary:** Indigo gradient (`primary` to `primary-dim`), white text (`on-primary`), and a `DEFAULT` (8px) corner radius.
*   **Secondary/Tonal:** `surface-container-highest` background with `primary` text. No border.
*   **Tertiary:** Pure text with `label-md` styling (uppercase + tracking).

### Cards & Lists
*   **Strict Rule:** No divider lines. Separate list items by increasing the vertical padding (e.g., 24px) or by using a `surface-container-low` background on hover.
*   **Structure:** Use `xl` (24px) padding inside cards to ensure the "Essentialist" feel.

### Input Fields
*   **Styling:** A flat `surface-container-low` background with a 1px `outline-variant` at 10% opacity. 
*   **Focus State:** Shift the background to `surface-container-lowest` and increase the `outline-variant` opacity to 40%. Avoid heavy "focus rings."

### Chips
*   **Style:** `surface-container-high` background, `8px` radius, and `label-sm` micro-typography. This makes the chip feel like a physical "tag" rather than a button.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical margins. A headline might be pushed 20% from the left to create a "white space" luxury feel.
*   **Do** use thin-stroke iconography (1px or 1.5px stroke weight) that matches the weight of the `label` typography.
*   **Do** use `surface-dim` for inactive states, maintaining a monochrome, sophisticated look.

### Don't
*   **Don't** use 100% black text. Use `on-surface` (#2a3439) for a softer, premium contrast.
*   **Don't** use standard "Drop Shadows" from default UI kits. Every shadow must be low-opacity and highly diffused.
*   **Don't** use high-contrast dividers. If you feel the need to separate two sections, increase the `margin-bottom` instead.
*   **Don't** use "saturated" error reds. Use the sophisticated `error` (#9e3f4e) which feels authoritative rather than alarming.